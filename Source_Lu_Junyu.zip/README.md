# Caculator
lab3,CS480, Central Washington University
Junyu Lu

A real number calculator using a graphic user interface that solves an expression.

INTRO:
This program is written in Java.
Write the unsolved expression in the text field, clicking the button "solve", the result will be shown in a message box.
Any expressions with the operator +,-,*,/,^ will be solved.
The operator '-' can't be used as a negative sign in front of a digit.

TO RUN:
The java code, jar file, and the executeable are doing the same thing.
The java code can be compiled by any java compiler such as javac. Running the code will get the user to the interface.
The jar file can be run on mac or windows.
The exe file can only run on windows.
  

ERROR HANDLING:
0 as the divisor will be treated as the limit to 0.
the uneven parathesis will be checked.
input with no numbers will be checked.
Other errors will be generally considered as opeartor error.
